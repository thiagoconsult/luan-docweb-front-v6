import { Component, OnInit, ViewChild , AfterViewInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PoBreadcrumb, PoPageAction, PoTableAction, PoTableColumn } from '@po-ui/ng-components';
import { DicionarioService } from '../services/dicionario.service';
import * as XLSX from 'xlsx';
@Component({
  selector: 'app-dicionario-view',
  templateUrl: './dicionario-view.component.html',
  styleUrls: ['./dicionario-view.component.css']
})
export class DicionarioViewComponent implements OnInit {

  // Variaveis para armazenar os parametros passados no component dicionario-info
  id: string  = '';



  breadcrumb: PoBreadcrumb | undefined;
  resultTabs: string[] | undefined

  // Variavel para armazenar os dados das tabelas com os resultados da comparações.
  tabelasItems: { [key: string]: any[] } = {};


  pageAction : PoPageAction[] = [
    
    {
      label: 'Exportar resultados',
      icon: 'po-icon po-icon-doc-xls',
      action: this.initializeTableItemsAndGenerateSheet.bind(this)
    },
  ]
  
  columnsDict: PoTableColumn[] = [
    { property: 'sequencia', label: 'ANALISE' },
    { property: 'instalacao', label: 'DICIONÁRIO' },
    { property: 'tabela', label: 'TABELA' },
    { property: 'chave', label: 'CHAVE' },
    { property: 'isOk', label: 'OK?' , visible: false},
    {
      property: 'dif',
      label: 'COLUNAS DIVERGENTES',
      type: 'cellTemplate'  // Indica que esta coluna utilizará um template personalizado
    }
  ];
  
  
column: any;
  


Array: any;
  //isHideLoading: boolean ;
  
  actions: Array<PoTableAction> = [
    {
        action: (row: any) => this.resolveDict([ row.sequencia] ,  [row.tabela]),
      label: 'Resolvido ',
      
    },


  ];




constructor(private route: ActivatedRoute, private dicionarioService: DicionarioService ){

}

ngOnInit(): void {
  this.route.params.subscribe(params => {
    this.id = params['id'];

  });


  this.setupBreadcrumb()
  this.initializeTableItems();

}

setupBreadcrumb(): void {


  this.breadcrumb = {
    items: [
      { label: 'Dicionários', link: '/main/dicionario/info' },
      { label: `Visualizar ${this.id} ` }
    ]
  };
}

initializeTableItems() {
  if (this.id ) {
    this.dicionarioService.getreturnAnalysis(this.id).subscribe({
      next: (result: any) => {
        // Itera sobre cada chave (tabela) no resultado
        Object.keys(result).forEach((tabela) => {
          // Verifica se result[tabela] é um array e não está vazio
          if (Array.isArray(result[tabela]) && result[tabela].length > 0) {
            // Mapeia cada item da tabela para formatar as diferencas
            result[tabela] = result[tabela].map((item: { diferencas: { [s: string]: unknown; } | ArrayLike<unknown>; }) => {
              // Formata as diferencas, se existirem
              if (item.diferencas) {
                const diferencas = Object.entries(item.diferencas)
                  .map(([key, value]) => `${key}: ${value}`)
                  .join(', ');
                
                // Retorna o item atualizado com as diferencas formatadas
                return {
                  ...item,
                  diferencas: diferencas
                };
              }
              // Retorna o item como está se não houver diferencas
              return item;
            });
          } else {
            // Se não for um array ou estiver vazio, configura uma mensagem padrão
            result[tabela] = [{ mensagem: 'Arquivo ainda em análise ou sem dados disponíveis.' }];
          }
        });
        
        this.tabelasItems = result;
        console.log('Dados recebidos:', result);
      },
      error: (error) => console.error('Erro ao buscar dados:', error),
    });
  } else {
    console.error('Um ou mais parâmetros necessários estão faltando.');
  }

  setTimeout(() => {
    //this.isHideLoading = true;
  }, 200);
}




initializeTableItemsAndGenerateSheet() {
  if (this.id) {
    this.dicionarioService.getreturnAnalysis(this.id).subscribe({
      next: (result: any) => {
        this.gerarPlanilhaComDados(result);
      },
      error: (error) => console.error('Erro ao buscar dados:', error),
    });
  } else {
    console.error('Um ou mais parâmetros necessários estão faltando.');
  }
}

private gerarPlanilhaComDados(dados: any) {
  const wb: XLSX.WorkBook = XLSX.utils.book_new();

  Object.keys(dados).forEach((tabela) => {
    // Limpa o nome da tabela, removendo espaços em branco e garantindo que não exceda 31 caracteres
    let nomeAba = tabela.replace(/\s+/g, ''); // Remove todos os espaços

    // Preparando os dados formatados
    const dadosFormatados = dados[tabela].map((item: any) => {
      // Extrai "diferencas" e "dict", removendo-os juntamente com "id" do resto
      const { id, diferencas, dict, ...resto } = item;


      // Formata "diferencas"
      const diferencasFormatadas = diferencas ? Object.entries(diferencas)
        .map(([chave, valor]) => `${chave}: ${valor}`)
        .join(', ') : '';


      
      const novoItem = {
        'DICIONARIO': dict || '', // Inserção "DICIONARIO" como primeira coluna
        ...resto, // Inserção das demais colunas
        'COLUNAS DIVERGENTES': diferencasFormatadas  // Inserção da "COLUNAS DIVERGENTES" como última coluna
      };

      return novoItem;
    });

    
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dadosFormatados);

    XLSX.utils.book_append_sheet(wb, ws, nomeAba);
  });

  // Gera o arquivo Excel e inicia o download
  XLSX.writeFile(wb, `analise_${this.id.replace(/:/g, '_')}.xlsx`);
}


resolveDict(analise: any , tabela: any){

    this.dicionarioService.updateAnalysis(this.id, analise, tabela).subscribe({
      next: (response) => console.log('Análise atualizada com sucesso:', response),
      error: (error) => console.error('Erro ao atualizar análise:', error)
    });
}





objectKeys(obj: any): string[] {
  return Object.keys(obj);
}


}

