import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalysisCreatComponent } from './analysis-creat.component';

describe('AnalysisCreatComponent', () => {
  let component: AnalysisCreatComponent;
  let fixture: ComponentFixture<AnalysisCreatComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AnalysisCreatComponent]
    });
    fixture = TestBed.createComponent(AnalysisCreatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
