import { Component } from '@angular/core';

@Component({
  selector: 'app-dicionario',
  templateUrl: './dicionario.component.html',
  styleUrls: ['./dicionario.component.css']
})
export class DicionarioComponent {

}
